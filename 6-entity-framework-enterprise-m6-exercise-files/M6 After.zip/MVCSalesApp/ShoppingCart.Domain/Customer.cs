namespace ShoppingCart.Domain
{
  public class Customer
  {
    public int CustomerId { get; private set; }
    public string CustomerCookie { get; private set; }
  }
}