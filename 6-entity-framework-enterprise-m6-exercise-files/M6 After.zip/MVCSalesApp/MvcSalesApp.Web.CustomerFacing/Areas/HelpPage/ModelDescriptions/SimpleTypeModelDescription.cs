namespace MvcSalesApp.Web.CustomerFacing.Areas.HelpPage.ModelDescriptions
{
    public class SimpleTypeModelDescription : ModelDescription
    {
    }
}